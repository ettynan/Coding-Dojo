$(document).ready(function(){

for (var i = 1; i < 152; i++){
    var image = "<img src=" + "http://pokeapi.co/media/img/" + i + ".png>";
    $("#mainContent").append(image);

    }


});
