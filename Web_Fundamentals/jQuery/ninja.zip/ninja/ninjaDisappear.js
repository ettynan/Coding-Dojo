$(document).ready(function(){
    $("#first").click(function(){
        $("#chainmail1").hide();
     });

    $("#second").click(function(){
        $("#chainmail2").hide();
    });

    $("#third").click(function(){
        $("#chainmail3").hide();
    });

    $("#fourth").click(function(){
        $("#chainmail4").hide();
    });

    $("#fifth").click(function(){
        $("#chainmail5").hide();
    });

    $("#sixth").click(function(){
        $("#chainmail6").hide();
    });

    $("#seventh").click(function(){
        $("#chainmail7").hide();
    });

    $("#eigth").click(function(){
        $("#chainmail8").hide();
    });

    $("#restore").click(function(){
        $("#chainmail1").show();
        $("#chainmail2").show();
        $("#chainmail3").show();
        $("#chainmail4").show();
        $("#chainmail5").show();
        $("#chainmail6").show();
        $("#chainmail7").show();
        $("#chainmail8").show();
    });

});
