
class Animal(object): #Class
    def __init__(self, name, health = 100): #initialize with attributes
        self.name = name #set attibutes = self.attribute
        self.health = health
    
    def walk(self):
        if self.health > 1:
            self.health -= 1
        return self

    def run(self):
        if self.health >5:
            self.health -= 5
        return self

    def displayHealth(self):
        print "Name:", self.name
        print "Health:", self.health
        return self

animal1 = Animal("tim")

animal1.walk().walk().walk().run().run().displayHealth()

