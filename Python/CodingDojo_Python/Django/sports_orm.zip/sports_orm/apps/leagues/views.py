from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Q
from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(), #Select * from leagues
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
        #level 1
        "baseball": League.objects.filter(name__contains = "Baseball"),
        "womens": League.objects.filter(name__contains = "Womens"),
        "hockey": League.objects.filter(name__contains = "Hockey"),
        "football": League.objects.exclude(name__contains = "Football"),
        "conference": League.objects.filter(name__contains = "Conference"),
        "atlantic": League.objects.filter(name__contains = "Atlantic"),
        "dallas": Team.objects.filter(location__contains = "Dallas"),
        "raptors": Team.objects.filter(team_name__contains = "Raptors"),
        "city": Team.objects.filter(location__contains = "City"),
        "starts_T": Team.objects.filter(team_name__startswith = "T"),
        "alphabetical_location": Team.objects.order_by("location"),
        "reverse_alphabet": Team.objects.order_by("-team_name"),
        "Cooper": Player.objects.filter(last_name__contains = "Cooper"),
        "Joshua": Player.objects.filter(first_name__contains = "Joshua"),
        "CooperMinusJoshua": Player.objects.filter(last_name__contains = "Cooper").exclude(first_name="Joshua"),
        "AlexanderWyatt": Player.objects.filter(Q(first_name__contains = "Alexander") | Q(first_name__contains = "Wyatt")),
    }

	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")