from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'ThisIsSecret'#need to set a key for security purposes
#index route will handle rendering out form
@app.route('/')
def index():
    return render_template("index.html")
#this route will handle our form submission
#notice how we defined which HTTP methos are allowed byt his route
@app.route('/users', methods=['POST'])
def create_user():
    print "Got Post Info"
    #the next two lines we'll address soon after more info on forms
    session['name'] = request.form['name']
    session['email'] = request.form['email']
    # session['female'] = request.form['female']
    # session['male'] = request.form['male']
    # session['other'] = request.form['other']
    # session['subscribe'] = request.form['subscribe']
    #redirecting back to the '/'route
    return redirect('/show')#changed from '/' to allow us to go to the page that displays the name, email, etc

@app.route('/show')
def show_user():
    return render_template('user.html', name = session['name'], email = session['email'])
    #, female=session['female'], male=session['male'], other=session['other'], subscribe=session['subscribe'])
app.run(debug=True) #run our server